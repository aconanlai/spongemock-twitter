# spongemock twitter chrome extension

--

chrome extension for automating '[mocking spongebob](http://knowyourmeme.com/memes/mocking-spongebob)' twitter replies

adds a 'reply as mocking spongebob' button to all tweets on twitter, automating the mOcKiNg TeXt FoRmAt and image insertion

pUlL rEqEuStS hApPiLly AcCePtEd - mAdE wItH 🤮 bY a CoNaN lAi