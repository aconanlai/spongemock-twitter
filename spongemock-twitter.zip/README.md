# spongemock twitter chrome extension

--
![spongemock screenshot](https://raw.githubusercontent.com/aconanlai/spongemock-twitter/master/spongescreenshot.png)

`[chrome extension](https://chrome.google.com/webstore/detail/spongemock/bofinkiibnkifejfhmdgenhmbikjnmbj)' for automating '[mocking spongebob](http://knowyourmeme.com/memes/mocking-spongebob)' twitter replies

**adds a 'reply as mocking spongebob' button to all tweets on twitter**, inserting the tweet in mOcKiNg TeXt FoRmAt ++ spongebob image

pUlL rEqEuStS hApPiLly AcCePtEd - mAdE wItH lOvE bY a CoNaN lAi